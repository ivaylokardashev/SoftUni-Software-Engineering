a = [1, 5, 3]
b = [1, 3, 5]

if a:
    print("Yes")