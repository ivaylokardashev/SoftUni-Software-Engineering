def raiser(ex):
    raise ex